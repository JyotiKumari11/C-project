# car-rental-system-using-mysql
how to create car rental system in c++ with mysql
if you want to watch the video for better understanding about the given code then click on given link:
https://youtu.be/fdWRjI2tNSk
 
